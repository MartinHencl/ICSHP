﻿using System;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LigaMistru
{
    // Spojový seznam by měl realizovat rozhraní IEnumerable, ICollection a IList
    // Shoddu prvků testujte pomocí metody Equals
    // Doplňte Equals do třídy Hrac

    public class SpojovySeznam
    {
        // ...
    }
}
